﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaNotas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string nombre;

                Console.WriteLine("Registro de Notas\n");
                Console.WriteLine("Ingrese el nombre del estudiante");
                nombre = Console.ReadLine();

                double suma = 0;
                double[] notas = new double[4];

                /*INSERCION DE LAS NOTAS*/
                for (int i = 0; i < notas.Length; i++)
                { 
                    Console.WriteLine($"\nIngresar nota #{i + 1}");
                    notas[i] = Double.Parse(Console.ReadLine());
                    suma += notas[i];

                    if(notas[i] < 0 || notas[i] > 100) /*VALIDA QUE LAS NOTAS ESTEN DENTRO DE UN RANGO*/
                        throw new ArgumentOutOfRangeException("Valor fuera del rango permitido.");
                }

                double promedio = suma / notas.Length; /*CALCULA LA CALIFICAION FINAL*/

                /*MUESTRA LOS RESULTADOS*/
                if (promedio >= 70)
                {
                    Console.WriteLine($"\nEstudiante {nombre}");
                    Console.WriteLine($"Calificacion: {promedio:F2}");
                    Console.WriteLine("Aprobado");
                }
                else
                {
                    Console.WriteLine($"\nEstudiante {nombre}");
                    Console.WriteLine($"Calificacion: {promedio:F2}");
                    Console.WriteLine("Reprobado");
                }
            }
            catch (FormatException) /*FORMATO INGRESADO INCORRECTO*/
            {
                Console.WriteLine("Error: Formato ingresado invalido.");
            }
            catch (ArgumentOutOfRangeException) /*VALIDA QUE LAS NOTAS ESTEN DENTRO DE UN RANGO*/
            {
                Console.WriteLine("Valor fuera del rango permitido.");
            }
            catch (ArgumentNullException ex) /*VALIDA QUE NO ESTE VACIO*/
            {
                Console.WriteLine(ex.Message);
            }
            catch (IOException) /*ERROR AL LEER EL VALOR*/
            {
                Console.WriteLine("Error al leer");
            }
            finally /*MENSAJE FINAL (NO VARIA)*/
            {
                Console.WriteLine("\n\n-- Programa Finalizado. --");
            }

            Console.ReadKey();
        }
    }
}
